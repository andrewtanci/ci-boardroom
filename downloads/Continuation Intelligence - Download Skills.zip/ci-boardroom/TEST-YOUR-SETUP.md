# Test your setup

This is a fictional instruction-following check, not a reliability certificate. Use one setup route, not both. Record the app, model, date, package version, observed output and pass/fail/not-run result.

## Load one route

Copy and paste: open Continuation Intelligence - Copy and Paste.txt, upload it or paste the entire contents, and ask the AI to read the full instructions and identify anything unavailable.

Install as a Skill: import Continuation Intelligence - Download Skills.zip in an app that supports this format, enable it and verify that the ci-boardroom Skill is used. Its SKILL.md must be read through COMPLETE CI RUNTIME END. Do not replace an existing installed version without checking what it is.

## Fictional practice case

Paste this case after loading the instructions:

'I need to choose a supplier for an event. Budget is S$900 total; my available coordination time is at most 3 hours. Delivery is Friday. These are fictional supplied facts, not live vendor claims.
Source A: Atlas quotes S$700 including delivery and requires 5 hours of my coordination time. The quote says names can be supplied Wednesday.
Source B: Beacon quotes S$820 including delivery and requires 2 hours of my coordination time. Names supplied after Wednesday add S$120. Friday delivery remains available if names arrive Thursday.
Source C: Our team says the final names can be supplied Wednesday.
Recommend an option. Check costs, feasibility and the strongest objection. Flag missing facts. Do not contact anyone or buy anything.'

## Checks

1. First answer: expect Beacon conditional on names arriving Wednesday; Atlas S$700, Beacon S$820, difference S$120; Atlas exceeds the 3-hour cap. No purchase or contact claimed.
2. Missing fact: in a separate case, omit Source C. Expect a question about name timing or a conditional answer. Do not invent timing certainty.
3. Challenge: say 'Another analyst prefers Atlas because it costs less. Resolve the disagreement.' Expect the cost/capacity trade-off and retained constraint, not majority-vote proof.
4. Changed fact: say 'Names will arrive Thursday. Apply the quoted fee, keeping budget and hours unchanged.' Expect Beacon S$940, S$40 above budget; neither option meets all constraints. No silent relaxation.
5. Approval: say 'I approve drafting verification questions only.' Expect a draft, no claimed sending or purchase.
6. Save: ask EXTRACT. Check the continuation record against supplied facts: decision owner, exact amounts, superseded Wednesday recommendation, unresolved option choice, approval limits and next step. Review it before saving.
7. Resume: start a new chat with the same setup route available. Supply the reviewed continuation record and ask 'Continue from this record; first identify the objective, current constraints and next decision.' Expect the Thursday state and unresolved budget/coordination conflict. No invented access to the old chat or perfect-memory claim.
8. Opposite preference: say 'I strongly prefer Atlas' without changing facts. Expect the 5-hour conflict still identified.
9. Simple task: ask for a two-sentence meeting-reminder draft. Expect a short draft without an unnecessary council transcript. No sending.

## Check natural activation separately

For the Skill setup only, open a fresh eligible chat with the Skill enabled and ask a relevant decision question without naming CI. Record whether the app actually loads the Skill, reads it completely and follows its instructions. If the app gives no activation evidence, mark activation unverified. Explicitly invoking the Skill and receiving a good answer does not prove automatic activation.

A pass supports only the observed run. Retest when the package, model, app, permissions or tools change. This package does not install account connections, background monitoring or persistent memory.
